<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('other.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 margin" >
                <img src="  <?php echo e(URL::asset('/img/'.$topic->img_url)); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1 class="center"> <?php echo e($topic->title); ?></h1>
                  <center>  <p class="center large" > <?php echo e($topic->content); ?> </p></center>
                    
                </section>
            </div> 
         

        </div>

</div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/index/topic.blade.php ENDPATH**/ ?>
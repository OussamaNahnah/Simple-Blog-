<!DOCTYPE html>
<html >
    <head>
        <meta charset="utf-8">

        <title>Topics</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
          @font-face {
            font-family: "rushink";
            src: url("rushink.ttf")format("ttf");
            src: url("rd.otf")format("otf");
        }
        
        @font-face {
            font-family: "boughiesdemo";
            src: url("boughiesdemo.ttf");
            src: url("boughiesdemo.ttf") format("ttf");
        }
        
        @import  url('https://fonts.googleapis.com/css?family=Poppins:700&display=swap');
        
        </style>
  <link href="<?php echo e(URL::to('/css/style.css')); ?>" rel="stylesheet">
    </head>
    <body>
  
    <header class="bgimage"> Tobic Programming</header>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 margin">
                <img src="  <?php echo e(URL::asset('/img/java.jpg')); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1>tilte</h1>
                    <p>this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                        normal </p>
                </section>
            </div>    <div class="col-sm-3 margin">
                <img src="  <?php echo e(URL::asset('/img/java.jpg')); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1>tilte</h1>
                    <p>this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                        normal </p>
                </section>
            </div>    <div class="col-sm-3 margin">
                <img src="  <?php echo e(URL::asset('/img/java.jpg')); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1>tilte</h1>
                    <p>this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                        normal </p>
                </section>
            </div>    <div class="col-sm-3 margin">
                <img src="  <?php echo e(URL::asset('/img/java.jpg')); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1>tilte</h1>
                    <p>this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                        normal </p>
                </section>
            </div>    <div class="col-sm-3 margin">
                <img src="  <?php echo e(URL::asset('/img/java.jpg')); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1>tilte</h1>
                    <p>this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                        normal </p>
                </section>
            </div>

        </div>


    </body>
</html>
<?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/topics.blade.php ENDPATH**/ ?>
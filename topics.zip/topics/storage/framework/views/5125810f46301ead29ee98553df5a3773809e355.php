<?php $__env->startSection('content'); ?>
<?php echo $__env->make('other.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-12 margin">
        <img src="  <?php echo e(URL::asset('/img/laravel.png')); ?> " class="img-circle  mycustomimg" alt="cinque terre">
        <section>
            <h1 class="center" >Presentation de Projet de larvavel : G1T</h1>
            <p class="simplemargin">this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                normal </p>
        </section>
    </div> 
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/other/about.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('other.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="center">update Topic</h1>
<form  method="post" action="<?php echo e(route('admin.update_ok',[$topic->id ])); ?>">
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">

<center><input class="large"   placeholder="Image URL of Topic" type="text" name="img" value="<?php echo e($topic->img_url); ?>"></br></center>
<center><input class="large"  placeholder="Name Of Topic:" type="text" name="title" value="<?php echo e($topic->title); ?>"> </br></center>
<center><input class="large"  placeholder="Content Of Topic:" type="text" name="content" value="<?php echo e($topic->content); ?>"></br></center>
<center><input class="large" type="submit" value="Save"></center>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/admin/update.blade.php ENDPATH**/ ?>
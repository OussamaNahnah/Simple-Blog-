<?php $__env->startSection('content'); ?>
<?php echo $__env->make('other.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="center">Edit Topic</h1>
<?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3 margin" >
                <img src="  <?php echo e(URL::asset('/img/'.$topic->img_url)); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1 class="center"> <?php echo e($topic->title); ?></h1>
                    <p class="center maxlength"> <?php echo e($topic->content); ?> </p>
                    <center> <a href="<?php echo e(route('admin.deleted',[$topic->id])); ?>">delete</a></center>
                </section>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/admin/delete.blade.php ENDPATH**/ ?>
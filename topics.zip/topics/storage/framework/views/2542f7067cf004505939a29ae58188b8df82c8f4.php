<?php $__env->startSection('content'); ?>
<?php echo $__env->make('other.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="center">Create Topic</h1>

<form  method="post" action="<?php echo e(route('admin.insert')); ?>">
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<center><input class="large"   placeholder="Image URL of Topic" type="text" name="img"></br></center>
<center><input class="large"  placeholder="Name Of Topic:" type="text" name="title"></br></center>
<center><input class="large"  placeholder="Content Of Topic:" type="text" name="content"></br></center>
<center><input class="large" type="submit" value="Save"></center>
</form>
<!--
a href="<?php echo e(route('index.topics')); ?>"></a>

    <form method="post" action="">
<label>Name Of Topic:</label><input type="text"></br>
<label>Content Of Topic:</label><input type = "text"></br>
<label></label><a href="<?php echo e(route('index.topics')); ?>"><input type="submit" value="Save"></a>
</form>
-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/admin/create.blade.php ENDPATH**/ ?>
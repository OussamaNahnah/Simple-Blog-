<?php $__env->startSection('content'); ?>

<?php echo $__env->make('other.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 



    <header class="bgimage"> Tobic Programming</header>
    <?php if(Session::has('created')): ?>
    <div class="alert-wrap">
<div class="alert alert-success">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <i class="fa fa-check"></i> <strong>Success!</strong> <?php echo e(Session::get('created')); ?>

</div></div>
<?php endif; ?>
<?php if(Session::has('updated')): ?>
    <div class="alert-wrap">
<div class="alert alert-success">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <i class="fa fa-check"></i> <strong>Success!</strong> <?php echo e(Session::get('updated')); ?>

</div></div>
<?php endif; ?>
<?php if(Session::has('deleted')): ?>
    <div class="alert-wrap">
<div class="alert alert-danger">
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <i class="fa fa-times"></i> <strong>Deleted</strong> <?php echo e(Session::get('deleted')); ?> 
</div></div>
<?php endif; ?>

<div class="container-fluid">
        <div class="row">
         
            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3 margin" >
                <img src="  <?php echo e(URL::asset('/img/'.$topic->img_url)); ?> " class="img-circle myimg" alt="cinque terre">
                <section>
                    <h1 class="center"> <?php echo e($topic->title); ?></h1>
                    <p class="center maxlength"> <?php echo e($topic->content); ?> </p>
                       <center> <a href="<?php echo e(route('index.topic',[$topic->id ])); ?>">Read More...</a></center>
                </section>
            </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

</div>


   <?php $__env->stopSection(); ?>

<?php echo $__env->make('index.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/oussamanh/Projects/LARAVEL/topics/resources/views/index/topics.blade.php ENDPATH**/ ?>
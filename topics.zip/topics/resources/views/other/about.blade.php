@extends('index.master')
@section('content')
@include('other.header')
<div class="row">
    <div class="col-sm-12 margin">
        <img src="  {{URL::asset('/img/laravel.png')}} " class="img-circle  mycustomimg" alt="cinque terre">
        <section>
            <h1 class="center" >Presentation de Projet de larvavel : G1T</h1>
            <p class="simplemargin">this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is normal this is normalthis is normal this is normal this is normal this is normal this is normal this is normal this is
                normal </p>
        </section>
    </div> 
</div> 
@endsection